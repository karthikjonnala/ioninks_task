from django.contrib import admin
from .models import MovieDetails

# Register your models here.
admin.site.register(MovieDetails)